/* Kunio Comey
 * CS202
 * Program 5
 * Main.java
 *
 * This is the main class for where the program will run from.
 */

package com.company;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        Application myApp = new Application();
        myApp.run();
    }
}
