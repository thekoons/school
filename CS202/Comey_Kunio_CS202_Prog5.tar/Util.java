//Kunio Comey
//CS202
//Program 4
//Util.java

//Class that is used to implement the scanner object without needing
//to create an input field.

package com.company;
import java.util.Scanner;
public class Util {
    protected Scanner input;
    public Util() {
        input = new Scanner(System.in);
    }
}
