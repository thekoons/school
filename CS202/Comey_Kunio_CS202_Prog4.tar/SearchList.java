/* Kunio Comey
 * CS202
 * Program 5
 * SearchList.java
 *
 * This class will deal with connecting the hash table list node to the
 * List node in the list found in the tree. This will allow operations
 * linked to searching and retrieving
 */

package com.company;

public class SearchList {
    protected ListNode connect;
    protected SearchList next;

    public SearchList() {
        connect = null;
        next = null;
    }

    public void setConnect(final ListNode temp) {
        connect = temp;
    }

    public void setNext(final SearchList temp) {
        next = temp;
    }

    public void display() {
        connect.display();
    }

    public int compare(final Data toComp) {
        return connect.compare(toComp);
    }

    public void search(final String toComp) {
        if(connect.compare(toComp) == 0) {
            System.out.println("\nPost found!");
            connect.display();
            return;
        }

        if(next == null) {
            System.out.println("\nCould not find post...");
            return;
        }

        next.search(toComp);
    }


}
